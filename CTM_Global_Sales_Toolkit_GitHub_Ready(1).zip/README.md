# CTM Global Sales Toolkit

This repository is ready for GitHub Pages.

## Files

- `index.html` — main toolkit page

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` to the root of the repository.
3. Go to **Settings**.
4. Select **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch: `main`.
7. Select folder: `/root`.
8. Click **Save**.
9. GitHub will provide a public web link after deployment.

## Updating the page later

Replace the existing `index.html` file in GitHub with the updated version, then commit the change.
